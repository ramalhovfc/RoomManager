This directory contains third-party dependencies installed with `pip`.
